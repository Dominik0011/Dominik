var numer = Math.floor(Math.random()*4)+1;

var timer1 = 0;
var timer2 = 0;

function ustaw(nrslajdu)
{
    clearTimeout(timer1);
    clearTimeout(timer2);
    numer = nrslajdu -1;

    setTimeout("slajd()", 500)
}


function slide()
{
    numer++; if(numer>4)numer=1;
    var plik = "<img src=\"z" + numer + ".jpg\"/>";

    document.getElementById("slider").innerHTML = plik;
    timer1 = setTimeout("slide()",5000);
    timer2 = setTimeout("ustaw()",4500)
    
}