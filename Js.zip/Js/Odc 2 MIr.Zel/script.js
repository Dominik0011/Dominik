function sprawdz()
{
    var wartosc = document.getElementById("pole").value;
    
    if(wartosc>0) document.getElementById("wynik").innerHTML = "dodatnia";
    
    else if (wartosc < 0) document.getElementById("wynik").innerHTML = "ujemna";

    else document.getElementById("wynik").innerHTML = "zero";
}
function wypisz()
{
    var liczba1 = document.getElementById("pole1").value;
    var liczba2 = document.getElementById("pole2").value;

    var napis = "";
    for(i=liczba1; i<=liczba2; i++)
    {
        napis=napis + i + " ";
    }
    document.getElementById("wynik2").innerHTML = napis;
}