var haslo = "Tylko Barcelona";
haslo = haslo.toUpperCase();

var dlugosc = haslo.length;
var ile_skuch = 0;

var yes = new Audio("yes.wav");
var no = new Audio("no.wav");

var haslo1 = "";

for(i=0; i<dlugosc; i++)
{
    if(haslo.charAt(i)==" ") haslo1 = haslo1 + " ";
    else haslo1 = haslo1 + "-";
}

function wypisz()
{
    document.getElementById("plansza").innerHTML = haslo1;
}

window.onload = start;

var litery = new Array(35);

//#region tablica litery 
litery[0] = "A";
litery[1] = "Ą";
litery[2] = "B";
litery[3] = "C";
litery[4] = "Ć";
litery[5] = "D";
litery[6] = "E";
litery[7] = "Ę";
litery[8] = "F";
litery[9] = "G";
litery[10] = "H";
litery[11] = "I";
litery[12] = "J";
litery[13] = "K";
litery[14] = "L";
litery[15] = "Ł";
litery[16] = "M";
litery[17] = "N";
litery[18] = "Ń";
litery[19] = "O";
litery[20] = "Ó";
litery[21] = "P";
litery[22] = "Q";
litery[23] = "R";
litery[24] = "S";
litery[25] = "Ś";
litery[26] = "T";
litery[27] = "U";
litery[28] = "V";
litery[29] = "W";
litery[30] = "X";
litery[31] = "Y";
litery[32] = "Z";
litery[33] = "Ż";
litery[34] = "Ź";
//#endregion
function start()
{
    var tresc = "";

    for(i = 0; i<=34; i++)
    {
        var element = "lit" + i;
        tresc = tresc + '<div class="litera" onclick="sprawdz('+i+')" id="'+element+'">'+litery[i]+'</div>';
        if((i+1)% 7 == 0) tresc = tresc + '<div style="clear:both"></div>';
    }

    document.getElementById("alfabet").innerHTML = tresc;

    wypisz();
}

String.prototype.Znak = function(miejsce, znak)
{
    if(miejsce > this.length -1) return this.toString();
    else return this.substr(0, miejsce) + znak + this.substr(miejsce+1);
}

function sprawdz(numer)
{
    var trafiona = false;

    for(i=0; i<dlugosc; i++)
    {
        if(haslo.charAt(i) == litery[numer])
        {
            haslo1 = haslo1.Znak(i,litery[numer]);
            trafiona = true;
        }
    }
    if(trafiona==true)
    {
        yes.play();
        var element = "lit" + numer;
        document.getElementById(element).style.background = "green"
        document.getElementById(element).style.cursor = "default"

        wypisz();
    }
    else
    {
        no.play();
        var element = "lit" + numer;
        document.getElementById(element).style.background = "red"
        document.getElementById(element).style.cursor = "default"

        document.getElementById(element).setAttribute("onclick",";");

        ile_skuch++;
        var obraz = "img/s" + ile_skuch + ".jpg";
        document.getElementById("szubienica").innerHTML = '<img src= "'+obraz+'" alt="" />'
    }

    //wygrana
    if(haslo == haslo1)
    document.getElementById("alfabet").innerHTML = 'Tak jest! Podano prawidłowe hasło: '+haslo+'<br/><br/><span class="reset" onclick="location.reload()">Jeszcze Raz?'

    //Przegrana
    if(ile_skuch>=9)
    document.getElementById("alfabet").innerHTML = 'Pregrana! Prawidłowe hasło: '+haslo+'<br/><br/><span class="reset" onclick="location.reload()">Jeszcze Raz?'

}